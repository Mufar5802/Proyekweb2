  <!-- Vendor JS Files -->
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/chart.js/chart.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/quill/quill.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?php echo base_url('niceadmin')?>/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url('niceadmin')?>/assets/js/main.js"></script>

</body>

</html>