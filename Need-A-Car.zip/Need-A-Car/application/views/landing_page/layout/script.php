<!-- Vendor JS Files -->
<script src="<?php echo base_url('herobiz/')?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('herobiz/')?>assets/vendor/aos/aos.js"></script>
<script src="<?php echo base_url('herobiz/')?>assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?php echo base_url('herobiz/')?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?php echo base_url('herobiz/')?>assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo base_url('herobiz/')?>assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?php echo base_url('herobiz/')?>assets/js/main.js"></script>

</body>

</html>